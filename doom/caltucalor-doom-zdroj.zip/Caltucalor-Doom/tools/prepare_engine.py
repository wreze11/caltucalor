#!/usr/bin/env python3
"""Připraví engine Doomu (doomgeneric, GPL v2) pro Caltucalor: zkopíruje zdrojáky a provede
malé úpravy označené CALTUCALOR (paměť zóny, WAD z paměti, konec hry, složka uložených her …).

  prepare_engine.py <doomgeneric/doomgeneric> <cíl>
"""
import os, re, shutil, sys

src, dst = sys.argv[1], sys.argv[2]
SRC_DOOM = """dummy am_map doomdef doomstat dstrings d_event d_items d_iwad d_loop d_main d_mode d_net f_finale f_wipe
g_game hu_lib hu_stuff info i_cdmus i_endoom i_joystick i_scale i_sound i_system i_timer memio m_argv m_bbox m_cheat
m_config m_controls m_fixed m_menu m_misc m_random p_ceilng p_doors p_enemy p_floor p_inter p_lights p_map p_maputl
p_mobj p_plats p_pspr p_saveg p_setup p_sight p_spec p_switch p_telept p_tick p_user r_bsp r_data r_draw r_main
r_plane r_segs r_sky r_things sha1 sounds statdump st_lib st_stuff s_sound tables v_video wi_stuff w_checksum
w_file w_main w_wad z_zone i_input i_video doomgeneric""".split()

if os.path.isdir(dst):
    shutil.rmtree(dst)
os.makedirs(dst)
for f in sorted(os.listdir(src)):
    if f.endswith('.h') or (f.endswith('.c') and f[:-2] in SRC_DOOM):
        shutil.copy(os.path.join(src, f), os.path.join(dst, f))
shutil.copy(os.path.join(src, '..', 'LICENSE'), os.path.join(dst, 'LICENSE'))
shutil.copy(os.path.join(src, '..', 'README.md'), os.path.join(dst, 'README-doomgeneric.md'))
try:
    import subprocess
    head = subprocess.run(['git', '-C', os.path.join(src, '..'), 'log', '-1', '--format=%H %cd'],
                          capture_output=True, text=True).stdout.strip()
except Exception:
    head = ''
open(os.path.join(dst, 'UPSTREAM.txt'), 'w').write('https://github.com/ozkl/doomgeneric ' + head + '\n')

def patch(name, pairs):
    p = os.path.join(dst, name)
    s = open(p, encoding='latin-1').read()
    for old, new in pairs:
        if s.count(old) != 1:
            raise SystemExit('%s: %r nalezeno %dx' % (name, old[:60], s.count(old)))
        s = s.replace(old, new)
    open(p, 'w', encoding='latin-1').write(s)

HOOKS = '#include "dg_hooks.h" /* CALTUCALOR */\n'

# paměť zóny z PSRAM, konec hry a chyba přes platformu, bez zenity / system()
patch('i_system.c', [
    ('#include "config.h"\n', '#include "config.h"\n' + HOOKS),
    ('        zonemem = malloc(*size);\n',
     '#ifdef CALTUCALOR\n        zonemem = DG_AllocZone(*size);\n#else\n        zonemem = malloc(*size);\n#endif\n'),
    ('#if ORIGCODE\n    SDL_Quit();\n\n    exit(0);\n#endif\n}',
     '#if ORIGCODE\n    SDL_Quit();\n\n    exit(0);\n#endif\n#ifdef CALTUCALOR\n    DG_Quit();\n#endif\n}'),
    ('    exit_gui_popup = !M_ParmExists("-nogui");\n',
     '#ifdef CALTUCALOR\n    DG_Error(msgbuf);\n#endif\n    exit_gui_popup = !M_ParmExists("-nogui");\n'),
    ('#if !defined(_WIN32) && !defined(__MACOSX__) && !defined(__DJGPP__)\n#define ZENITY_BINARY',
     '#if !defined(_WIN32) && !defined(__MACOSX__) && !defined(__DJGPP__) && !defined(CALTUCALOR)\n#define ZENITY_BINARY'),
])
# zenity: volání v I_Error vypnout (funkce výše se nepřekládá)
p = os.path.join(dst, 'i_system.c')
s = open(p, encoding='latin-1').read()
s = s.replace('#else\n    {\n        ZenityErrorBox(msgbuf);\n    }\n#endif',
              '#elif !defined(CALTUCALOR)\n    {\n        ZenityErrorBox(msgbuf);\n    }\n#endif', 1)
open(p, 'w', encoding='latin-1').write(s)

# WAD je v paměti (na ESP ve flash) – jméno "doom1.wad" vždycky "existuje"
patch('d_iwad.c', [
    ('#include "config.h"\n', '#include "config.h"\n' + HOOKS),
    ('    if (M_FileExists(name))\n    {\n        return name;\n    }\n\n    BuildIWADDirList();',
     '#ifdef CALTUCALOR\n    if (DG_WadExists(name))\n    {\n        return name;\n    }\n#endif\n'
     '    if (M_FileExists(name))\n    {\n        return name;\n    }\n\n    BuildIWADDirList();'),
])

# nastavení a uložené hry do složky platformy
patch('m_config.c', [
    ('#include "config.h"\n', '#include "config.h"\n' + HOOKS),
    ('static char *GetDefaultConfigDir(void)\n{\n',
     'static char *GetDefaultConfigDir(void)\n{\n#ifdef CALTUCALOR\n    return strdup(DG_ConfigDir());\n#endif\n'),
    ('        savegamedir = M_StringJoin(configdir, DIR_SEPARATOR_S, ".savegame/", NULL);',
     '#ifdef CALTUCALOR\n        savegamedir = M_StringJoin(configdir, "save/", NULL);\n#else\n'
     '        savegamedir = M_StringJoin(configdir, DIR_SEPARATOR_S, ".savegame/", NULL);\n#endif'),
])

# obraz kreslí Doom do rychlé paměti (na ESP interní RAM)
patch('i_video.c', [
    ('#include "doomgeneric.h"\n', '#include "doomgeneric.h"\n' + HOOKS),
    ('	I_VideoBuffer = (byte*)Z_Malloc (SCREENWIDTH * SCREENHEIGHT, PU_STATIC, NULL);',
     '#ifdef CALTUCALOR\n	I_VideoBuffer = (byte*)DG_AllocVideo (SCREENWIDTH * SCREENHEIGHT);\n#else\n'
     '	I_VideoBuffer = (byte*)Z_Malloc (SCREENWIDTH * SCREENHEIGHT, PU_STATIC, NULL);\n#endif'),
])

# buffer obrazovky jen 1 bajt na pixel (CMAP256)
patch('doomgeneric.c', [
    ('	DG_ScreenBuffer = malloc(DOOMGENERIC_RESX * DOOMGENERIC_RESY * 4);',
     '	DG_ScreenBuffer = malloc(DOOMGENERIC_RESX * DOOMGENERIC_RESY * sizeof(pixel_t));'),
])
# konec bez textové obrazovky ENDOOM (doomgeneric po ní volá exit(0) – a to by nebyl návrat do kalkulačky)
patch('d_main.c', [
    ('    // Don\'t show ENDOOM if we have it disabled, or we\'re running\n',
     '#ifdef CALTUCALOR\n    return;\n#endif\n    // Don\'t show ENDOOM if we have it disabled, or we\'re running\n'),
])

# velká pole (visplanes 85 kB, openings 40 kB, ticdata 20 kB) do velké paměti (na ESP32 PSRAM) – do interní RAM se nevejdou
patch('r_plane.c', [
    ('#include "i_system.h"\n', '#include "i_system.h"\n' + HOOKS),
    ('visplane_t\t\tvisplanes[MAXVISPLANES];',
     '#ifdef CALTUCALOR\nvisplane_t\t\t*visplanes;\n#else\nvisplane_t\t\tvisplanes[MAXVISPLANES];\n#endif'),
    ('short\t\t\topenings[MAXOPENINGS];',
     '#ifdef CALTUCALOR\nshort\t\t\t*openings;\n#else\nshort\t\t\topenings[MAXOPENINGS];\n#endif'),
    ('void R_InitPlanes (void)\n{\n',
     'void R_InitPlanes (void)\n{\n#ifdef CALTUCALOR\n  if (visplanes == NULL)\n  {\n'
     '    visplanes = (visplane_t *)DG_AllocBig(sizeof(visplane_t) * MAXVISPLANES);\n'
     '    openings = (short *)DG_AllocBig(sizeof(short) * MAXOPENINGS);\n'
     '    if (visplanes == NULL || openings == NULL) I_Error("R_InitPlanes: no memory");\n  }\n#endif\n'),
])
patch('d_loop.c', [
    ('#include "i_system.h"\n', '#include "i_system.h"\n' + HOOKS),
    ('static ticcmd_set_t ticdata[BACKUPTICS];',
     '#ifdef CALTUCALOR\nstatic ticcmd_set_t *ticdata;\n#else\nstatic ticcmd_set_t ticdata[BACKUPTICS];\n#endif'),
    ('void D_RegisterLoopCallbacks(loop_interface_t *i)\n{\n',
     'void D_RegisterLoopCallbacks(loop_interface_t *i)\n{\n#ifdef CALTUCALOR\n    if (ticdata == NULL)\n'
     '        ticdata = (ticcmd_set_t *)DG_AllocBig(sizeof(ticcmd_set_t) * BACKUPTICS);\n'
     '    if (ticdata == NULL) I_Error("D_RegisterLoopCallbacks: no memory");\n'
     '    memset(ticdata, 0, sizeof(ticcmd_set_t) * BACKUPTICS);\n#endif\n'),
])

# uložení bez psaní jména: prázdná pozice dostane jméno HRA n (Enter = uložit)
patch('m_menu.c', [
    ('    saveCharIndex = strlen(savegamestrings[choice]);\n}',
     '#ifdef CALTUCALOR\n    if (savegamestrings[choice][0] == 0)\n'
     '        M_snprintf(savegamestrings[choice], SAVESTRINGSIZE, "HRA %d", choice + 1);\n#endif\n'
     '    saveCharIndex = strlen(savegamestrings[choice]);\n}'),
])
open(os.path.join(dst, 'library.json'), 'w', encoding='utf-8').write("""{
  "name": "doomgeneric",
  "version": "0.0.0",
  "description": "Doom engine (doomgeneric, GPL v2) s upravami CALTUCALOR",
  "license": "GPL-2.0-only",
  "build": { "flags": ["-w", "-I../doomport"], "includeDir": "." }
}
""")
print('engine:', len([f for f in os.listdir(dst) if f.endswith('.c')]), 'souborů .c ->', dst)
