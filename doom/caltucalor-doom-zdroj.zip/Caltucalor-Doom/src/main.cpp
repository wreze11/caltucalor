// main.cpp – Doom pro kalkulačku Caltucalor (Seeed XIAO ESP32S3, verze s dotykovou klávesnicí)
//
// Samostatný program v oddílu flash "doom". Spouští ho kalkulačka: zapíše do NVS ("doom" / "hw")
// zapojení a nastavení displejů a dotyku, přepne spouštěný oddíl sem a restartuje se. Doom hned na
// začátku přepne spouštění zpátky na kalkulačku – každý restart (konec hry, chyba, vypnutí) tak
// vede do kalkulačky. Hra je na hlavním displeji (320 x 200), ovládání na displeji klávesnice.
// WAD (DOOM1.WAD, shareware) je v oddílu "wad" a čte se přímo z flash, uložené hry jsou na
// malém LittleFS v oddílu "doomsav".
//
// Licence: GPL v2 (Doom / doomgeneric). Viz README.md a LICENSE.
#include <Arduino.h>
#include <LittleFS.h>
#include <Preferences.h>
#include <Wire.h>
#include <driver/gpio.h>
#include <driver/spi_master.h>
#include <esp_heap_caps.h>
#include <esp_ota_ops.h>
#include <esp_partition.h>
#include <string.h>

#include "DoomHw.h"
#include "doomport.h"

extern "C" {
#include "doomgeneric.h"
}

SET_LOOP_TASK_STACK_SIZE(32 * 1024); // Doom má hluboké volání (BSP, AI) a větší lokální proměnné

namespace {

doomhw::Hw hw;
bool hwOk = false;

// ---------------------------------------------------------------- displeje (SPI s DMA)
const spi_host_device_t kHost = SPI2_HOST;
const int kBandBytes = 480 * 8 * 2; // jeden pruh obrazu (dva buffery: DMA posílá jeden, CPU plní druhý)
// buffery jsou společné pro oba displeje (před přepnutím na druhý displej se vždycky dočká konce DMA)
uint16_t* bandBuf[2] = {nullptr, nullptr};

class Lcd
{
public:
    bool ok = false;
    int w = 320, h = 240;

    bool begin(const doomhw::Display& d, uint32_t hz)
    {
        d_ = d;
        w = d.w;
        h = d.h;
        if (d.cs < 0 || d.dc < 0) return false;
        gpio_reset_pin((gpio_num_t)d.dc);
        gpio_set_direction((gpio_num_t)d.dc, GPIO_MODE_OUTPUT);
        gpio_set_level((gpio_num_t)d.dc, 1);
        spi_device_interface_config_t cfg;
        memset(&cfg, 0, sizeof(cfg));
        cfg.clock_speed_hz = (int)hz;
        cfg.mode = 0;
        cfg.spics_io_num = d.cs;
        cfg.queue_size = 3;
        cfg.flags = SPI_DEVICE_HALFDUPLEX | SPI_DEVICE_NO_DUMMY;
        if (spi_bus_add_device(kHost, &cfg, &dev_) != ESP_OK) return false;
        for (int i = 0; i < 2; i++)
        {
            if (bandBuf[i] == nullptr) bandBuf[i] = (uint16_t*)heap_caps_malloc(kBandBytes, MALLOC_CAP_DMA | MALLOC_CAP_INTERNAL);
            if (bandBuf[i] == nullptr) return false;
        }
        ok = true;
        init();
        return true;
    }

    void waitIdle()
    {
        while (queued_ > 0)
        {
            spi_transaction_t* t = nullptr;
            spi_device_get_trans_result(dev_, &t, portMAX_DELAY);
            queued_--;
        }
    }

    void command(uint8_t cmd, const uint8_t* data = nullptr, int len = 0)
    {
        waitIdle();
        spi_transaction_t t;
        memset(&t, 0, sizeof(t));
        gpio_set_level((gpio_num_t)d_.dc, 0);
        t.length = 8;
        t.flags = SPI_TRANS_USE_TXDATA;
        t.tx_data[0] = cmd;
        spi_device_polling_transmit(dev_, &t);
        gpio_set_level((gpio_num_t)d_.dc, 1);
        if (len > 0)
        {
            memset(&t, 0, sizeof(t));
            t.length = (size_t)len * 8;
            if (len <= 4)
            {
                t.flags = SPI_TRANS_USE_TXDATA;
                memcpy(t.tx_data, data, (size_t)len);
            }
            else
            {
                t.tx_buffer = data;
            }
            spi_device_polling_transmit(dev_, &t);
        }
    }

    // obdélník po pruzích: fill(ctx, y, rows, dst) naplní rows řádků (bajty už prohozené pro SPI)
    typedef void (*Fill)(void* ctx, int y, int rows, int w, uint16_t* dst);
    void push(int x, int y, int rw, int rh, Fill fill, void* ctx, bool wait)
    {
        if (!ok || rw <= 0 || rh <= 0) return;
        window(x, y, rw, rh);
        int rows = (kBandBytes / 2) / rw;
        if (rows < 1) rows = 1;
        for (int yy = y; yy < y + rh;)
        {
            const int n = (y + rh - yy < rows) ? y + rh - yy : rows;
            if (queued_ >= 2)
            {
                spi_transaction_t* done = nullptr;
                spi_device_get_trans_result(dev_, &done, portMAX_DELAY);
                queued_--;
            }
            uint16_t* b = bandBuf[next_];
            fill(ctx, yy, n, rw, b);
            spi_transaction_t& t = trans_[next_];
            memset(&t, 0, sizeof(t));
            t.length = (size_t)n * rw * 16;
            t.tx_buffer = b;
            if (spi_device_queue_trans(dev_, &t, portMAX_DELAY) == ESP_OK) queued_++;
            next_ ^= 1;
            yy += n;
        }
        if (wait) waitIdle();
    }

private:
    void window(int x, int y, int ww, int hh)
    {
        const uint8_t ca[4] = {(uint8_t)(x >> 8), (uint8_t)x, (uint8_t)((x + ww - 1) >> 8), (uint8_t)(x + ww - 1)};
        const uint8_t ra[4] = {(uint8_t)(y >> 8), (uint8_t)y, (uint8_t)((y + hh - 1) >> 8), (uint8_t)(y + hh - 1)};
        command(0x2A, ca, 4);
        command(0x2B, ra, 4);
        command(0x2C);
    }

    void init()
    {
        struct Cmd
        {
            uint8_t cmd, len;
            uint8_t data[15];
            uint8_t wait;
        };
        if (d_.chip == 2)
        {
            // ST7796S (3,5" 480 x 320) – stejná inicializace jako v kalkulačce (TFT_eSPI)
            static const Cmd init[] = {
                {0xF0, 1, {0xC3}, 0},
                {0xF0, 1, {0x96}, 0},
                {0x3A, 1, {0x55}, 0},
                {0xB4, 1, {0x01}, 0},
                {0xB6, 3, {0x80, 0x02, 0x3B}, 0},
                {0xE8, 8, {0x40, 0x8A, 0x00, 0x00, 0x29, 0x19, 0xA5, 0x33}, 0},
                {0xC1, 1, {0x06}, 0},
                {0xC2, 1, {0xA7}, 0},
                {0xC5, 1, {0x18}, 120},
                {0xE0, 14, {0xF0, 0x09, 0x0B, 0x06, 0x04, 0x15, 0x2F, 0x54, 0x42, 0x3C, 0x17, 0x14, 0x18, 0x1B}, 0},
                {0xE1, 14, {0xE0, 0x09, 0x0B, 0x06, 0x04, 0x03, 0x2B, 0x43, 0x42, 0x3B, 0x16, 0x14, 0x17, 0x1B}, 120},
                {0xF0, 1, {0x3C}, 0},
                {0xF0, 1, {0x69}, 120},
            };
            command(0x01); // softwarový reset (RST je společný – resetoval ho už hlavní displej)
            delay(150);
            command(0x11);
            delay(120);
            for (const Cmd& c : init)
            {
                command(c.cmd, c.data, c.len);
                if (c.wait) delay(c.wait);
            }
        }
        else if (d_.chip == 1)
        {
            // ILI9341
            static const Cmd init[] = {
                {0xEF, 3, {0x03, 0x80, 0x02}, 0},
                {0xCF, 3, {0x00, 0xC1, 0x30}, 0},
                {0xED, 4, {0x64, 0x03, 0x12, 0x81}, 0},
                {0xE8, 3, {0x85, 0x00, 0x78}, 0},
                {0xCB, 5, {0x39, 0x2C, 0x00, 0x34, 0x02}, 0},
                {0xF7, 1, {0x20}, 0},
                {0xEA, 2, {0x00, 0x00}, 0},
                {0xC0, 1, {0x23}, 0},
                {0xC1, 1, {0x10}, 0},
                {0xC5, 2, {0x3E, 0x28}, 0},
                {0xC7, 1, {0x86}, 0},
                {0x37, 1, {0x00}, 0},
                {0x3A, 1, {0x55}, 0},
                {0xB1, 2, {0x00, 0x18}, 0},
                {0xB6, 3, {0x08, 0x82, 0x27}, 0},
                {0xF2, 1, {0x00}, 0},
                {0x26, 1, {0x01}, 0},
                {0xE0, 15, {0x0F, 0x31, 0x2B, 0x0C, 0x0E, 0x08, 0x4E, 0xF1, 0x37, 0x07, 0x10, 0x03, 0x0E, 0x09, 0x00}, 0},
                {0xE1, 15, {0x00, 0x0E, 0x14, 0x03, 0x11, 0x07, 0x31, 0xC1, 0x48, 0x08, 0x0F, 0x0C, 0x31, 0x36, 0x0F}, 0},
            };
            command(0x01);
            delay(150);
            for (const Cmd& c : init) command(c.cmd, c.data, c.len);
            command(0x11);
            delay(150);
        }
        else
        {
            // ST7789
            command(0x01);
            delay(150);
            command(0x11);
            delay(120);
            const uint8_t colmod = 0x55;
            command(0x3A, &colmod, 1);
            delay(10);
            command(0x13); // NORON
            delay(10);
        }
        command(0x36, &d_.madctl, 1);
        command(d_.invOn ? 0x21 : 0x20);
        clear();
        command(0x29); // DISPON
        delay(20);
    }

    static void fillBlack(void*, int, int rows, int rw, uint16_t* dst) { memset(dst, 0, (size_t)rows * rw * 2); }
    void clear() { push(0, 0, w, h, fillBlack, nullptr, true); }

    doomhw::Display d_;
    spi_device_handle_t dev_ = nullptr;
    spi_transaction_t trans_[2];
    int queued_ = 0;
    int next_ = 0;
};

Lcd mainLcd, kbLcd;
uint16_t* kbFb = nullptr;

void busIdle()
{
    mainLcd.waitIdle();
    kbLcd.waitIdle();
}

bool initBus()
{
    spi_bus_config_t bus;
    memset(&bus, 0, sizeof(bus));
    bus.mosi_io_num = hw.mosi;
    bus.miso_io_num = -1;
    bus.sclk_io_num = hw.sck;
    bus.quadwp_io_num = -1;
    bus.quadhd_io_num = -1;
    bus.max_transfer_sz = kBandBytes;
    return spi_bus_initialize(kHost, &bus, SPI_DMA_CH_AUTO) == ESP_OK;
}

void hardReset()
{
    if (hw.main.rst < 0) return;
    gpio_reset_pin((gpio_num_t)hw.main.rst);
    gpio_set_direction((gpio_num_t)hw.main.rst, GPIO_MODE_OUTPUT);
    gpio_set_level((gpio_num_t)hw.main.rst, 1);
    delay(5);
    gpio_set_level((gpio_num_t)hw.main.rst, 0);
    delay(20);
    gpio_set_level((gpio_num_t)hw.main.rst, 1);
    delay(150);
}

void backlight(bool on)
{
    if (hw.bl < 0) return;
    gpio_reset_pin((gpio_num_t)hw.bl);
    gpio_set_direction((gpio_num_t)hw.bl, GPIO_MODE_OUTPUT);
    gpio_set_level((gpio_num_t)hw.bl, (on == (hw.blActiveHigh != 0)) ? 1 : 0);
}

// ---------------------------------------------------------------- dotyk (I2C)
uint8_t i2cAddr = 0;
int gtX[2] = {0, 0}, gtY[2] = {0, 0};
int gtN = 0;

bool readReg(uint8_t reg, uint8_t* b, int n)
{
    Wire.beginTransmission(i2cAddr);
    Wire.write(reg);
    if (Wire.endTransmission(false) != 0) return false;
    if (Wire.requestFrom((uint16_t)i2cAddr, (size_t)n, true) != (size_t)n) return false;
    for (int i = 0; i < n; i++) b[i] = (uint8_t)Wire.read();
    return true;
}

bool readReg16(uint16_t reg, uint8_t* b, int n)
{
    Wire.beginTransmission(i2cAddr);
    Wire.write((uint8_t)(reg >> 8));
    Wire.write((uint8_t)(reg & 0xFF));
    if (Wire.endTransmission(false) != 0) return false;
    if (Wire.requestFrom((uint16_t)i2cAddr, (size_t)n, true) != (size_t)n) return false;
    for (int i = 0; i < n; i++) b[i] = (uint8_t)Wire.read();
    return true;
}

void writeReg16(uint16_t reg, uint8_t v)
{
    Wire.beginTransmission(i2cAddr);
    Wire.write((uint8_t)(reg >> 8));
    Wire.write((uint8_t)(reg & 0xFF));
    Wire.write(v);
    Wire.endTransmission(true);
}

// surové body čipu (až 2 prsty)
int readRaw(int* rx, int* ry)
{
    uint8_t b[16];
    switch (hw.tpChip)
    {
    case 1: // FT6x36: dva body
    {
        if (!readReg(0x02, b, 11)) return 0;
        const int n = b[0] & 0x0F;
        int k = 0;
        for (int i = 0; i < 2 && i < n; i++)
        {
            const uint8_t* p = b + 1 + i * 6;
            if ((p[0] >> 6) == 1) continue; // prst se právě zvedl
            rx[k] = ((p[0] & 0x0F) << 8) | p[1];
            ry[k] = ((p[2] & 0x0F) << 8) | p[3];
            k++;
        }
        return n > 5 ? 0 : k;
    }
    case 2: // CST816: jeden bod
    {
        if (!readReg(0x02, b, 5)) return 0;
        const int n = b[0] & 0x0F;
        if (n < 1 || n > 5) return 0;
        rx[0] = ((b[1] & 0x0F) << 8) | b[2];
        ry[0] = ((b[3] & 0x0F) << 8) | b[4];
        return 1;
    }
    case 3: // CST328: jeden bod
    {
        if (!readReg16(0xD005, b, 1)) return 0;
        const int n = b[0] & 0x0F;
        if (n == 0 || n > 5)
        {
            writeReg16(0xD005, 0);
            return 0;
        }
        if (!readReg16(0xD000, b, 5)) return 0;
        writeReg16(0xD005, 0);
        if ((b[0] & 0x0F) != 0x06) return 0;
        rx[0] = (b[1] << 4) | (b[3] >> 4);
        ry[0] = (b[2] << 4) | (b[3] & 0x0F);
        return 1;
    }
    case 4: // GT911: až dva body, posílá jen změny
    {
        if (!readReg16(0x814E, b, 1)) return 0;
        if (b[0] & 0x80)
        {
            const int n = b[0] & 0x0F;
            gtN = 0;
            if (n > 0 && n <= 5)
            {
                uint8_t p[16];
                const int take = n < 2 ? n : 2;
                if (readReg16(0x814F, p, 8 * take))
                    for (int i = 0; i < take; i++)
                    {
                        gtX[i] = p[i * 8 + 1] | (p[i * 8 + 2] << 8);
                        gtY[i] = p[i * 8 + 3] | (p[i * 8 + 4] << 8);
                        gtN++;
                    }
            }
            writeReg16(0x814E, 0);
        }
        for (int i = 0; i < gtN; i++)
        {
            rx[i] = gtX[i];
            ry[i] = gtY[i];
        }
        return gtN;
    }
    default: return 0;
    }
}

// ---------------------------------------------------------------- oddíly flash
const uint8_t* wadData = nullptr;
size_t wadSize = 0;
bool savesOk = false;

void bootCalculator()
{
    // každý další start (konec, chyba, vypnutí) už zase kalkulačka
    const esp_partition_t* calc = esp_partition_find_first(ESP_PARTITION_TYPE_APP, ESP_PARTITION_SUBTYPE_APP_OTA_0, nullptr);
    if (calc != nullptr) esp_ota_set_boot_partition(calc);
}

bool mapWad()
{
    const esp_partition_t* p = esp_partition_find_first(ESP_PARTITION_TYPE_DATA, ESP_PARTITION_SUBTYPE_ANY, "wad");
    if (p == nullptr) return false;
    const void* ptr = nullptr;
    spi_flash_mmap_handle_t handle;
    if (esp_partition_mmap(p, 0, p->size, SPI_FLASH_MMAP_DATA, &ptr, &handle) != ESP_OK) return false;
    wadData = (const uint8_t*)ptr;
    // skutečná délka souboru: konec adresáře lumpů
    dp::Wad w;
    w.data = wadData;
    w.size = p->size;
    if (!w.valid()) return false;
    size_t end = (size_t)dp::Wad::le32(wadData + 8) + (size_t)w.lumps() * 16;
    const uint8_t* dir = wadData + dp::Wad::le32(wadData + 8);
    for (int i = 0; i < w.lumps(); i++)
    {
        const size_t e = (size_t)dp::Wad::le32(dir + i * 16) + (size_t)dp::Wad::le32(dir + i * 16 + 4);
        if (e > end) end = e;
    }
    wadSize = end <= p->size ? end : p->size;
    return true;
}

void fillRed(void*, int, int rows, int rw, uint16_t* dst)
{
    for (int i = 0; i < rows * rw; i++) dst[i] = 0x0060; // tmavě červená (bajty prohozené)
}

void showMessage(const char* title, const char* text)
{
    Serial.printf("%s: %s\n", title, text);
    if (!dp::wad().valid())
    {
        // bez WADu není písmo – aspoň červený hlavní displej
        if (mainLcd.ok) mainLcd.push(0, 0, mainLcd.w, mainLcd.h, fillRed, nullptr, true);
        return;
    }
    if (kbFb == nullptr || !kbLcd.ok) return;
    dp::pad().message(title, text);
    dp::Rect all;
    all.w = kbLcd.w;
    all.h = kbLcd.h;
    dp::platKbRect(kbFb, kbLcd.w, all);
}

[[noreturn]] void restartToCalculator(uint32_t waitMs)
{
    busIdle();
    delay(waitMs);
    bootCalculator();
    esp_restart();
    for (;;) delay(1000);
}

struct FrameCtx
{
    const uint8_t* px;
    int w, top;
    uint16_t lut[256];
};

void fillFrame(void* ctx, int y, int rows, int w, uint16_t* dst)
{
    const FrameCtx* f = (const FrameCtx*)ctx;
    const uint8_t* src = f->px + (size_t)(y - f->top) * f->w;
    for (int r = 0; r < rows; r++)
    {
        const uint8_t* s = src + (size_t)r * f->w;
        uint16_t* d = dst + (size_t)r * w;
        for (int i = 0; i < w; i++) d[i] = f->lut[s[i]];
    }
}

struct KbCtx
{
    const uint16_t* fb;
    int fbW, x;
};

void fillKb(void* ctx, int y, int rows, int w, uint16_t* dst)
{
    const KbCtx* k = (const KbCtx*)ctx;
    for (int r = 0; r < rows; r++)
    {
        const uint16_t* s = k->fb + (size_t)(y + r) * k->fbW + k->x;
        uint16_t* d = dst + (size_t)r * w;
        for (int i = 0; i < w; i++) d[i] = (uint16_t)((s[i] >> 8) | (s[i] << 8));
    }
}

FrameCtx frameCtx;

} // namespace

// ---------------------------------------------------------------- platforma pro doomport
namespace dp {

uint32_t platMs() { return millis(); }
void platSleep(uint32_t ms) { delay(ms); }

int platTouch(Point* pts, int max)
{
    if (hw.tpChip == 0 || !hw.calValid) return 0;
    int rx[2], ry[2];
    const int n = readRaw(rx, ry);
    int k = 0;
    for (int i = 0; i < n && k < max; i++)
    {
        const float u = (float)(hw.calSwap ? ry[i] : rx[i]);
        const float v = (float)(hw.calSwap ? rx[i] : ry[i]);
        int x = (int)lroundf(hw.ax * u + hw.bx), y = (int)lroundf(hw.ay * v + hw.by);
        x = x < 0 ? 0 : (x >= kbLcd.w ? kbLcd.w - 1 : x);
        y = y < 0 ? 0 : (y >= kbLcd.h ? kbLcd.h - 1 : y);
        pts[k].x = x;
        pts[k].y = y;
        k++;
    }
    return k;
}

void platFrame(const uint8_t* px, int w, int h, const uint16_t* lut)
{
    // obraz 320 x 200 doprostřed hlavního displeje (nahoře a dole 20 px černá)
    mainLcd.waitIdle();
    kbLcd.waitIdle();
    for (int i = 0; i < 256; i++) frameCtx.lut[i] = (uint16_t)((lut[i] >> 8) | (lut[i] << 8));
    frameCtx.px = px;
    frameCtx.w = w;
    frameCtx.top = mainLcd.h > h ? (mainLcd.h - h) / 2 : 0;
    const int rows = h < mainLcd.h ? h : mainLcd.h;
    mainLcd.push(0, frameCtx.top, w < mainLcd.w ? w : mainLcd.w, rows, fillFrame, &frameCtx, false);
}

void platKbRect(const uint16_t* fb, int fbW, const Rect& r)
{
    if (!kbLcd.ok) return;
    mainLcd.waitIdle();
    KbCtx k{fb, fbW, r.x};
    kbLcd.push(r.x, r.y, r.w, r.h, fillKb, &k, true);
}

void platQuit()
{
    showMessage("DOOM", "ZPET DO KALKULACKY...");
    restartToCalculator(300);
}

void platError(const char* msg)
{
    showMessage("CHYBA DOOMU", msg);
    restartToCalculator(6000);
}

void* platAllocZone(int size)
{
    void* p = heap_caps_malloc((size_t)size, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    Serial.printf("PSRAM %d kB: %s\n", size / 1024, p ? "ok" : "NE");
    return p;
}

void* platAllocVideo(int size)
{
    // do interní RAM jen když v ní zbude rezerva (zásobník, I2C, LittleFS, FreeRTOS), jinak PSRAM
    void* p = nullptr;
    if (heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT) >= (size_t)size + 24 * 1024)
        p = heap_caps_malloc((size_t)size, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    if (p == nullptr) p = heap_caps_malloc((size_t)size, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    return p;
}

const char* platConfigDir() { return savesOk ? "/sav/" : "/neni/"; }

} // namespace dp

void setup()
{
    Serial.begin(115200);
    bootCalculator();

    // co předala kalkulačka
    Preferences prefs;
    if (prefs.begin("doom", true))
    {
        hwOk = prefs.getBytesLength("hw") == sizeof(hw) && prefs.getBytes("hw", &hw, sizeof(hw)) == sizeof(hw) &&
               hw.magic == doomhw::kMagic && hw.version == doomhw::kVersion && hw.size == sizeof(hw);
        prefs.end();
    }
    if (!hwOk)
    {
        Serial.println("Doom: chybi nastaveni z kalkulacky (NVS doom/hw) - zpet");
        restartToCalculator(0);
    }

    // displeje
    backlight(false);
    hardReset();
    const uint32_t hz = hw.spiHz >= 10000000 && hw.spiHz <= 80000000 ? hw.spiHz : 40000000;
    if (!initBus()) restartToCalculator(0);
    mainLcd.begin(hw.main, hz);
    if (hw.kb.cs >= 0) kbLcd.begin(hw.kb, hz);
    backlight(true);

    // WAD (bez něj není ani písmo – jen červený displej)
    if (!mapWad())
    {
        showMessage("DOOM NENI", "CHYBI DOOM1.WAD - NAINSTALUJ KALKULACKU Z WEBU ZNOVU");
        restartToCalculator(4000);
    }
    dp::setWad(wadData, wadSize);
    if (kbLcd.ok)
    {
        kbFb = (uint16_t*)heap_caps_malloc((size_t)kbLcd.w * kbLcd.h * 2, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
        if (kbFb != nullptr)
        {
            dp::pad().begin(kbLcd.w, kbLcd.h, kbFb, &dp::wad());
            showMessage("DOOM", "NACITAM...");
        }
    }

    // dotyk (adresa podle kalkulačky; GT911 může mít po resetu i tu druhou)
    if (hw.tpChip != 0 && hw.tpSda >= 0 && hw.tpScl >= 0)
    {
        Wire.begin(hw.tpSda, hw.tpScl, 100000);
        const uint8_t cand[3] = {hw.tpAddr, (uint8_t)(hw.tpChip == 4 ? (hw.tpAddr == 0x5D ? 0x14 : 0x5D) : hw.tpAddr), hw.tpAddr};
        i2cAddr = hw.tpAddr;
        for (int attempt = 0; attempt < 20; attempt++)
        {
            const uint8_t a = cand[attempt % 3];
            Wire.beginTransmission(a);
            if (Wire.endTransmission(true) == 0)
            {
                i2cAddr = a;
                break;
            }
            delay(25); // (čip dotyku se po resetu chvíli probouzí)
        }
    }

    // uložené hry (poprvé se oddíl naformátuje – pár sekund)
    savesOk = LittleFS.begin(true, "/sav", 4, "doomsav");
    Serial.printf("Doom: WAD %u B, ulozene hry %s, PSRAM volna %u kB, interni %u kB\n", (unsigned)wadSize, savesOk ? "ano" : "NE",
                  (unsigned)(heap_caps_get_free_size(MALLOC_CAP_SPIRAM) / 1024),
                  (unsigned)(heap_caps_get_free_size(MALLOC_CAP_INTERNAL) / 1024));

    dp::begin(wadData, wadSize, kbFb ? kbLcd.w : 0, kbFb ? kbLcd.h : 0, kbFb, hw.main.swapRB != 0);
    static char* args[] = {(char*)"doom", (char*)"-iwad", (char*)"doom1.wad", (char*)"-nogui", (char*)"-mb", (char*)"5", nullptr};
    doomgeneric_Create(6, args);
}

void loop() { doomgeneric_Tick(); }
