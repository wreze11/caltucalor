// DoomHw.h – co kalkulačka předává Doomu (NVS, jmenný prostor "doom", klíč "hw")
//
// Kalkulačka před spuštěním Doomu zapíše, jak jsou zapojené a nastavené displeje a dotyk (piny,
// řadiče, natočení, barvy, kalibrace), přepne spouštěný program na oddíl "doom" a restartuje se.
// Doom podle toho displeje a dotyk nastaví stejně. Stejný soubor je v kalkulačce i v Doomu.
#pragma once
#include <stdint.h>

namespace doomhw {

const uint32_t kMagic = 0x4D4F4F44; // "DOOM"
const uint16_t kVersion = 1;

struct Display
{
    uint8_t chip;   // 0 ST7789, 1 ILI9341, 2 ST7796S
    uint8_t madctl; // natočení a pořadí barev (příkaz 0x36) přesně jako v kalkulačce
    uint8_t invOn;  // 1 = poslat INVON (0x21), 0 = INVOFF (0x20)
    uint8_t swapRB; // 1 = prohodit červenou a modrou při kreslení (TFT_SWAP_RED_BLUE)
    int8_t cs, dc, rst;
    uint8_t reserved;
    uint16_t w, h; // rozměry tak, jak se kreslí (na šířku)
};

struct Hw
{
    uint32_t magic;
    uint16_t version;
    uint16_t size; // sizeof(Hw)
    int8_t sck, mosi, bl;
    uint8_t blActiveHigh;
    uint32_t spiHz;
    Display main;
    Display kb;
    int8_t tpSda, tpScl, tpRst;
    uint8_t tpChip; // 1 FT6x36, 2 CST816, 3 CST328, 4 GT911 (0 = žádný)
    uint8_t tpAddr;
    uint8_t calValid, calSwap;
    uint8_t reserved;
    float ax, bx, ay, by; // kalibrace: x = ax * u + bx, y = ay * v + by (u, v = osy čipu po swap)
};

} // namespace doomhw
