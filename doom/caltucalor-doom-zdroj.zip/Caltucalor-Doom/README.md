# Doom pro kalkulačku Caltucalor

Skrytá hra kalkulačky [Caltucalor](https://wreze11.github.io/caltucalor/) (Seeed XIAO ESP32S3, verze
s dotykovou klávesnicí): původní **Doom** (1993) – shareware, 1. epizoda *Knee-Deep in the Dead*, 9 levelů.

Hra je samostatný program ve vlastním oddílu flash. Kalkulačka ho spustí (v Nastavení 7× rychle ťuknout
na řádek Verze, nebo příkaz `doom`): zapíše do NVS (`doom` / `hw`, struktura v `src/DoomHw.h`), jak jsou
zapojené a nastavené displeje a dotyk, přepne spouštěný oddíl na `doom` a restartuje se. Doom hned po
startu přepne spouštění zpátky na kalkulačku, takže každý další restart (konec hry, chyba, vypnutí)
vede zase do kalkulačky.

- Obraz Doomu (320 × 200) je na hlavním displeji, ovládání na displeji klávesnice (480 × 320 nebo
  320 × 240): vlevo páčka (nahoru = dopředu, dolů = dozadu, do stran = otáčení, daleko od středu =
  běh), vpravo úkroky `<<` `>>`, **USE** (otevřít dveře; v otázkách menu „ano“), **FIRE** (střelba;
  v menu Enter), nahoře **MAP**, **LEVEL**, **WEAPON** (další zbraň), **MENU** a ikona kalkulačky –
  podržet 1,2 s = zpátky do kalkulačky (jde i přes menu Quit Game a USE). Dva prsty najednou (páčka +
  střelba) zvládne čip dotyku FT6x36 a GT911, CST816 jen jeden.
- **LEVEL**: výběr levelu E1M1–E1M9 a obtížnosti (nápisy M_JKILL … M_NMARE z menu, název WILV00 …
  z mezihry, lebka M_SKULL1). Během výběru je hra v pauze (v levelu; demo na titulní obrazovce běží
  dál), HRAT = `G_DeferedInitNew(skill, 1, map)` jako New Game (menu Doomu se zavře), ZPET pauzu zruší.
  Kreslí `DoomPad` (`openLevels`, `popLevelResult`), stav hry a skok jsou v C (`lib/doomport/dg_level.c`).
- Uložené hry jsou na malém LittleFS v oddílu `doomsav` (jméno pozice se doplní samo, Enter = FIRE).
- Zvuk není (kalkulačka nemá reproduktor).

## Oddíly flash (`partitions_doom.csv`)

| Oddíl | Adresa | Velikost | Co |
|---|---|---|---|
| nvs | 0x9000 | 20 kB | nastavení kalkulačky (stejné místo jako dřív – nic se neztratí) |
| otadata | 0xE000 | 8 kB | který program se spustí |
| app0 | 0x10000 | 2,5 MB | kalkulačka |
| doom | 0x290000 | 896 kB | tenhle program |
| wad | 0x370000 | 4 MB | DOOM1.WAD (shareware) |
| doomsav | 0x771000 | 572 kB | uložené hry (LittleFS) |

Instalace z webu (verze s dotykovou klávesnicí) nahraje všechno najednou. Ručně (esptool):

```
esptool.py --chip esp32s3 write_flash 0x290000 .pio/build/doom/firmware.bin 0x370000 DOOM1.WAD
```

(kalkulačka musí být přeložená se stejnou tabulkou oddílů: `board_build.partitions = partitions_doom.csv`).

## Jak je to uděláno

- `lib/doomgeneric` – engine [doomgeneric](https://github.com/ozkl/doomgeneric) (Chocolate Doom,
  GPL v2), commit v `UPSTREAM.txt`. Malé úpravy jsou označené `CALTUCALOR`; dělá je skript
  `tools/prepare_engine.py` (zóna a velká pole rendereru v PSRAM, obraz v interní RAM, WAD z paměti,
  konec hry bez `exit()`, složka uložených her, jméno uložené pozice se doplní samo).
- `lib/doomport` – spojení enginu s kalkulačkou: `doomport.cpp` (funkce `DG_*`, WAD čtený z flash,
  paleta), `doompad.cpp` (ovládání na dotykovém displeji, písmo z WADu), `wadfile.h`.
- `src/main.cpp` – ESP32-S3: displeje ST7789 / ILI9341 / ST7796S přes SPI s DMA, dotyk přes I2C
  (FT6x36, CST816, CST328, GT911), oddíly flash, LittleFS.
- Lumpy se kopírují do zóny (5 MB v PSRAM): ve WADu nejsou zarovnané a ESP32 neumí číst nezarovnaná slova.
- Velká pole, která jsou v původním Doomu statická (visplanes, openings, ticdata), jsou v PSRAM a nulují se
  (`DG_AllocBig`) – PSRAM po restartu z kalkulačky obsahuje zbytky jejího obrazu.
- Oba displeje dostanou každou sekundu znovu základní nastavení (SLPOUT, COLMOD, MADCTL, inverze, IDMOFF,
  NORON, DISPON) a displej klávesnice se po pruzích překreslí (celý za 10 s) – rušení na drátech může
  displeji poslat cizí příkaz. Kalkulačka totéž dělá s displejem klávesnice po 5 s bez kreslení.

Ověřené na PC (bez okna, virtuální čas, paměť zaplněná smetím – 0xFF i náhodně – jako PSRAM po restartu):
titulní obrazovka, menu, nová hra, chůze, běh, střelba dvěma prsty, úkrok, mapa, zbraň, uložení (asi 25 kB)
a nahrání hry, konec přes menu, všech 9 levelů s 3 MB zóny, dema; WAD jen pro čtení.

## Verze

- **7.9** – tlačítko LEVEL: výběr levelu a obtížnosti (test na PC: scénář `LEVELS=1`, i 320 × 240).
  Paleta z WADu se hledá jednou (kreslení písma bylo pomalé).
- **7.8** – oprava podle zkoušky na desce: hra hned v první úrovni spadla s `R_MapPlane: …, … at 255`
  (nevynulovaná pole rendereru v PSRAM) a displej klávesnice měl barvy jako negativ (teď každou sekundu
  znovu nastavení displejů). Hlášení chyby a načítání ukazují verzi hry.
- **7.7** – první verze (spolu s kalkulačkou 7.7).

## Licence

Engine doomgeneric a celý tenhle program: **GNU GPL v2** (soubor `LICENSE`). DOOM1.WAD je shareware
© id Software – smí se šířit zdarma a beze změny; plnou hru (DOOM.WAD) je potřeba si koupit.
Kalkulačka Caltucalor sama je samostatný program (Doom s ní sdílí jen oddíly flash a NVS).
