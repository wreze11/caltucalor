// wadfile.h – čtení souboru WAD přímo z paměti (na ESP32 je WAD ve flash, namapovaný do adres)
// Licence: GPL v2 (jako Doom).
#pragma once
#include <stddef.h>
#include <stdint.h>
#include <string.h>

namespace dp {

struct Wad
{
    const uint8_t* data = nullptr;
    size_t size = 0;

    static int32_t le32(const uint8_t* p) { return (int32_t)(p[0] | (p[1] << 8) | (p[2] << 16) | ((uint32_t)p[3] << 24)); }
    static int16_t le16(const uint8_t* p) { return (int16_t)(p[0] | (p[1] << 8)); }

    // hlavička "IWAD" nebo "PWAD" a adresář uvnitř souboru
    bool valid() const
    {
        if (data == nullptr || size < 12) return false;
        if (memcmp(data, "IWAD", 4) != 0 && memcmp(data, "PWAD", 4) != 0) return false;
        const int32_t n = le32(data + 4), ofs = le32(data + 8);
        return n > 0 && ofs > 0 && (size_t)ofs + (size_t)n * 16 <= size;
    }
    int lumps() const { return le32(data + 4); }
    // lump podle jména (poslední s tím jménem, jako Doom); nullptr = není
    const uint8_t* find(const char* name, int* len = nullptr) const
    {
        if (!valid()) return nullptr;
        const int n = lumps();
        const uint8_t* dir = data + le32(data + 8);
        for (int i = n - 1; i >= 0; i--)
        {
            const uint8_t* e = dir + i * 16;
            if (strncmp((const char*)e + 8, name, 8) == 0)
            {
                const int32_t pos = le32(e), l = le32(e + 4);
                if (pos < 0 || l < 0 || (size_t)pos + (size_t)l > size) return nullptr;
                if (len) *len = l;
                return data + pos;
            }
        }
        return nullptr;
    }
};

} // namespace dp
