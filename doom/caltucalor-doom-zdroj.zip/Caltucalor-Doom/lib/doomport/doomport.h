// doomport.h – Doom (doomgeneric) v kalkulačce Caltucalor: spojení enginu s platformou
//
// Engine volá funkce DG_* (doomgeneric.h) a háčky z dg_hooks.h – ty jsou v doomport.cpp a samy
// volají jen pár funkcí platformy (plat…), které jsou zvlášť pro ESP32 (src/main.cpp) a pro test
// na PC. WAD je v paměti jako jeden kus (na ESP32 oddíl flash namapovaný do adres) a Doom z něj
// čte přímo, nic se nekopíruje. Licence: GPL v2 (jako Doom).
#pragma once
#include <stddef.h>
#include <stdint.h>

#include "doompad.h"
#include "wadfile.h"

namespace dp {

// ---------------------------------------------------------------- platforma (implementuje main)
uint32_t platMs();
void platSleep(uint32_t ms);
int platTouch(Point* pts, int max); // dotyky na displeji klávesnice, počet (0 = nic)
// hotový snímek Doomu: w x h indexů barev + paleta 256 barev RGB565 (podle platformy už prohozená)
void platFrame(const uint8_t* px, int w, int h, const uint16_t* lut);
void platKbRect(const uint16_t* fb, int fbW, const Rect& r); // kus obrazu klávesnice na displej
void platQuit();                                              // konec hry – nevrací se
void platError(const char* msg);                              // chyba – nevrací se
void* platAllocZone(int size);
void* platAllocVideo(int size);
const char* platConfigDir();

// ---------------------------------------------------------------- port
// wad = celý soubor WAD v paměti; kbW x kbH = displej klávesnice (0 = žádný) a jeho buffer;
// swapRB = prohodit červenou a modrou v paletě (displej s BGR)
void begin(const uint8_t* wad, size_t wadLen, int kbW, int kbH, uint16_t* kbFb, bool swapRB);
void setWad(const uint8_t* wad, size_t wadLen); // jen WAD (písmo pro zprávy ještě před begin)
const Wad& wad();
DoomPad& pad();
void pollInput();          // dotyky -> klávesy Doomu (volá se z DG_GetKey nejvýš co 8 ms)
uint32_t frames();         // kolik snímků Doom nakreslil
const uint16_t* palette(); // aktuální paleta RGB565

} // namespace dp
