// doompad.h – ovládání Doomu na dotykovém displeji klávesnice (Caltucalor)
//
// Vlevo „páčka“ (prst nahoru = dopředu, dolů = dozadu, do stran = otáčení, daleko od středu = běh),
// vpravo úkroky << >>, USE (otevřít dveře, v menu „ano“) a FIRE (střelba, v menu Enter), nahoře
// návrat do kalkulačky (podržet), MAP, LEVEL (výběr levelu a obtížnosti, NOVÉ v7.9), WEAPON (další
// zbraň) a MENU. Funguje se dvěma prsty najednou (páčka + střelba). Kreslí se do bufferu RGB565
// velikosti displeje; písmo a nápisy jsou z WADu (STCFN, M_JKILL …, WILV00 …).
// Jen výpočty a kreslení do paměti – testuje se i na PC. Licence: GPL v2 (jako Doom).
#pragma once
#include <stdint.h>

#include "wadfile.h"

namespace dp {

struct Point
{
    int x, y;
};

struct Rect
{
    int x, y, w, h;
    Rect() : x(0), y(0), w(0), h(0) {}
    Rect(int x_, int y_, int w_, int h_) : x(x_), y(y_), w(w_), h(h_) {}
    bool contains(int px, int py) const { return px >= x && py >= y && px < x + w && py < y + h; }
};

class DoomPad
{
public:
    enum Button
    {
        Exit,
        Map,
        Weapon,
        Menu,
        Level, // NOVÉ (v7.9): výběr levelu a obtížnosti
        StrafeL,
        StrafeR,
        Use,
        Fire,
        Up, // šipky páčky (jen pro kreslení stavu)
        Down,
        Left,
        Right,
        kButtons
    };

    // rozměry displeje klávesnice (480 x 320 nebo 320 x 240) a buffer pro obraz (w * h pixelů)
    void begin(int w, int h, uint16_t* fb, const Wad* wad);
    void drawAll(); // celý obraz do bufferu (po begin)
    // celý displej klávesnice: nadpis a text (písmem Doomu, jen velká písmena bez diakritiky)
    void message(const char* title, const char* text);

    // dotyky (souřadnice na displeji klávesnice), now = ms; vygeneruje události kláves
    void update(const Point* pts, int n, uint32_t now);
    // další událost pro Doom: true = je; pressed 1/0, key = kód Doomu (doomkeys.h)
    bool popKey(int& pressed, unsigned char& key);
    // obdélník, který se změnil (stisknuté tlačítko) – už je překreslený v bufferu; false = nic
    bool popDirty(Rect& r);
    // tlačítko návratu do kalkulačky bylo drženo dost dlouho
    bool quitRequested() const { return quit_; }

    // NOVÉ (v7.9): výběr levelu a obtížnosti. Po ťuknutí na LEVEL vrátí popLevelRequest() jednou
    // true – doomport zjistí stav hry (a hru pozastaví) a zavolá openLevels. Na displeji je pak
    // panel: levely E1M1–E1M9, název vybraného, 5 obtížností (nápisy z menu Doomu), ZPET a HRAT.
    // Volba se vrátí přes popLevelResult. Každé ťuknutí = jedna akce (další až po zvednutí prstu).
    enum LevelResult
    {
        LevelNone,
        LevelPlay,  // HRAT: map 1–9, skill 0–4 (I'm too young to die … Nightmare!)
        LevelCancel // ZPET
    };
    bool popLevelRequest();
    void openLevels(int map, int skill);
    bool levelsOpen() const { return mode_ == ModeLevels; }
    LevelResult popLevelResult(int& map, int& skill);
    Rect levelRect(int map) const { return lvRects_[(map < 1 ? 1 : map > 9 ? 9 : map) - 1]; } // (pro testy)
    Rect skillRect(int skill) const { return skRects_[skill < 0 ? 0 : skill > 4 ? 4 : skill]; }
    Rect playRect() const { return playRect_; }
    Rect backRect() const { return backRect_; }
    bool pressed(Button b) const { return (state_ >> b) & 1u; }
    Rect rect(Button b) const { return rects_[b]; }
    int width() const { return w_; }
    int height() const { return h_; }

    static const unsigned char kKeyNextWeapon = ']'; // key_nextweapon (nastaví doomport)

private:
    int sx(int v) const { return (v * w_ + 240) / 480; } // návrh je pro 480 x 320
    int sy(int v) const { return (v * h_ + 160) / 320; }
    void layout();
    void drawButton(Button b);
    void frame(const Rect& r, bool on); // tlačítko: zaoblený rámeček a výplň
    // výběr levelu (NOVÉ v7.9)
    void releaseKeys(); // pustit všechny držené klávesy Doomu
    void updateLevels(const Point* pts, int n);
    void closeLevels(LevelResult res);
    void drawLevels();
    void drawLevelButton(int map);
    void drawSkillRow(int skill);
    void drawLevelName();
    void drawPlay();
    void addDirty(const Rect& r);
    void markDirty(Button b);
    void pushKey(int pressed, unsigned char key);
    // kreslení
    void fill(int x, int y, int w, int h, uint16_t c);
    void roundRect(const Rect& r, int rad, uint16_t c);
    void ring(int cx, int cy, int r0, int r1, uint16_t c);
    void triangle(float x0, float y0, float x1, float y1, float x2, float y2, uint16_t c);
    int textWidth(const char* s, float scale) const;
    void text(int x, int y, const char* s, float scale);
    // obrázek z WADu ve formátu patch (sloupce); vrací šířku v bodech displeje
    int drawPatch(const uint8_t* p, float x, int y, float scale);
    int patchW(const char* name) const;
    int patchH(const char* name) const;
    void textCentered(const Rect& r, const char* s, float scale);
    uint16_t pal(int idx) const; // barva z PLAYPAL

    int w_ = 480, h_ = 320;
    uint16_t* fb_ = nullptr;
    const Wad* wad_ = nullptr;
    const uint8_t* playpal_ = nullptr; // paleta z WADu (hledá se jednou – hledání lumpu je pomalé)
    Rect rects_[kButtons];
    Rect stickArea_;
    int cx_ = 0, cy_ = 0, rad_ = 0; // páčka
    uint32_t state_ = 0;            // stisknutá tlačítka (bity Button)
    uint32_t keys_ = 0;             // držené klávesy Doomu (bity podle kKeys)
    uint32_t exitSince_ = 0;
    bool quit_ = false;
    // výběr levelu (NOVÉ v7.9)
    enum Mode
    {
        ModePad,
        ModeLevels
    };
    Mode mode_ = ModePad;
    bool levelRequest_ = false;
    bool waitRelease_ = false; // po přepnutí obrazovky nebo akci počkat, až se prsty zvednou
    int selMap_ = 1, selSkill_ = 2;
    LevelResult levelResult_ = LevelNone;
    Rect lvRects_[9], skRects_[5], playRect_, backRect_, nameRect_;
    bool fullDirty_ = false;
    Rect extra_[12];
    int extraCount_ = 0;
    // fronta událostí
    struct Ev
    {
        uint8_t pressed, key;
    };
    Ev queue_[64];
    int qHead_ = 0, qTail_ = 0;
    uint32_t dirty_ = 0;
};

} // namespace dp
