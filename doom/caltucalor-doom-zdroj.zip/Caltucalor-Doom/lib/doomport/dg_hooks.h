/* dg_hooks.h – háčky, které engine (doomgeneric) volá v místech označených CALTUCALOR.
 * Implementuje je doomport.cpp. Licence: GPL v2 (jako Doom). */
#ifndef DG_HOOKS_H
#define DG_HOOKS_H

#ifdef __cplusplus
extern "C" {
#endif

void *DG_AllocZone(int size);   /* paměť zóny (na ESP32 v PSRAM) */
void *DG_AllocVideo(int size);  /* obraz 320 x 200, do kterého Doom kreslí (na ESP32 v rychlé interní RAM) */
void *DG_AllocBig(int size);    /* velká pole rendereru a sítě (na ESP32 v PSRAM – do interní RAM se nevejdou) */
void DG_Quit(void);             /* konec hry z menu – už se nevrátí (na ESP32 restart do kalkulačky) */
void DG_Error(const char *msg); /* chyba Doomu – už se nevrátí */
int DG_WadExists(const char *name);
const char *DG_ConfigDir(void); /* složka na nastavení a uložené hry, s lomítkem na konci */

#ifdef __cplusplus
}
#endif

#endif
