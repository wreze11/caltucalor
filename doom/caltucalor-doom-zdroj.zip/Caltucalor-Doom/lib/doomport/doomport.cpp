// doomport.cpp – funkce DG_* pro doomgeneric a háčky CALTUCALOR (viz doomport.h). Licence: GPL v2.
#include "doomport.h"

#include <stdlib.h>
#include <string.h>
#include <strings.h>

extern "C" {
#include "dg_hooks.h"
#include "doomgeneric.h"
#include "i_video.h"
#include "w_file.h"
extern int key_nextweapon;
void I_Quit(void);
}

namespace dp {

namespace {
Wad g_wad;
DoomPad g_pad;
uint16_t* g_kbFb = nullptr;
int g_kbW = 0, g_kbH = 0;
bool g_swapRB = false;
uint16_t g_lut[256];
bool g_lutReady = false;
uint32_t g_lastPoll = 0;
uint32_t g_frames = 0;
bool g_quitting = false;

void rebuildLut()
{
    for (int i = 0; i < 256; i++)
    {
        int r = colors[i].r, g = colors[i].g, b = colors[i].b;
        if (g_swapRB)
        {
            const int t = r;
            r = b;
            b = t;
        }
        g_lut[i] = (uint16_t)(((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3));
    }
    g_lutReady = true;
}

void flushPad()
{
    if (g_kbFb == nullptr) return;
    Rect r;
    while (g_pad.popDirty(r)) platKbRect(g_kbFb, g_kbW, r);
}
} // namespace

void begin(const uint8_t* wadData, size_t wadLen, int kbW, int kbH, uint16_t* kbFb, bool swapRB)
{
    g_wad.data = wadData;
    g_wad.size = wadLen;
    g_kbW = kbW;
    g_kbH = kbH;
    g_kbFb = kbFb;
    g_swapRB = swapRB;
    if (g_kbFb != nullptr && kbW > 0 && kbH > 0)
    {
        g_pad.begin(kbW, kbH, g_kbFb, &g_wad);
        g_pad.drawAll();
        Rect all;
        all.w = kbW;
        all.h = kbH;
        platKbRect(g_kbFb, kbW, all);
    }
}

void setWad(const uint8_t* wadData, size_t wadLen)
{
    g_wad.data = wadData;
    g_wad.size = wadLen;
}

const Wad& wad() { return g_wad; }
DoomPad& pad() { return g_pad; }
uint32_t frames() { return g_frames; }
const uint16_t* palette() { return g_lut; }

void pollInput()
{
    if (g_kbFb == nullptr) return;
    const uint32_t now = platMs();
    if (g_lastPoll != 0 && now - g_lastPoll < 8) return;
    g_lastPoll = now ? now : 1;
    Point pts[4];
    const int n = platTouch(pts, 4);
    g_pad.update(pts, n, now);
    flushPad();
}

} // namespace dp

using namespace dp;

// ---------------------------------------------------------------- WAD z paměti (místo w_file_stdc.c)
extern "C" {

static wad_file_t* MemOpen(char* path);
static void MemClose(wad_file_t* f);
static size_t MemRead(wad_file_t* f, unsigned int offset, void* buffer, size_t len);

wad_file_class_t stdc_wad_file = {MemOpen, MemClose, MemRead};

static wad_file_t* MemOpen(char* path)
{
    if (!DG_WadExists(path)) return NULL;
    wad_file_t* f = (wad_file_t*)malloc(sizeof(wad_file_t));
    if (f == NULL) return NULL;
    f->file_class = &stdc_wad_file;
    // Doom si lumpy kopíruje do zóny (zarovnané). Přímý ukazatel do WADu (mapped) by byl rychlejší,
    // ale lumpy ve WADu nejsou zarovnané na 4 bajty a ESP32 neumí číst nezarovnaná slova (výjimka
    // LoadStoreAlignment) – Doom čte ze struktur lumpů celá čísla rovnou přes ukazatele.
    f->mapped = NULL;
    f->length = (unsigned int)g_wad.size;
    return f;
}

static void MemClose(wad_file_t* f) { free(f); }

static size_t MemRead(wad_file_t* f, unsigned int offset, void* buffer, size_t len)
{
    if (offset >= f->length) return 0;
    if (len > f->length - offset) len = f->length - offset;
    memcpy(buffer, g_wad.data + offset, len);
    return len;
}

// ---------------------------------------------------------------- háčky CALTUCALOR
void* DG_AllocZone(int size) { return platAllocZone(size); }
void* DG_AllocVideo(int size) { return platAllocVideo(size); }
void* DG_AllocBig(int size) { return platAllocZone(size); }
void DG_Quit(void) { platQuit(); }
void DG_Error(const char* msg) { platError(msg); }
int DG_WadExists(const char* name)
{
    if (!g_wad.valid() || name == NULL) return 0;
    const char* base = strrchr(name, '/');
    base = base ? base + 1 : name;
    return strcasecmp(base, "doom1.wad") == 0;
}
const char* DG_ConfigDir(void) { return platConfigDir(); }

// ---------------------------------------------------------------- doomgeneric
void DG_Init()
{
    key_nextweapon = DoomPad::kKeyNextWeapon; // tlačítko WEAPON = další zbraň
}

void DG_DrawFrame()
{
    if (palette_changed || !g_lutReady)
    {
        rebuildLut();
        palette_changed = false;
    }
    g_frames++;
    platFrame((const uint8_t*)DG_ScreenBuffer, DOOMGENERIC_RESX, DOOMGENERIC_RESY, g_lut);
    flushPad();
}

void DG_SleepMs(uint32_t ms) { platSleep(ms); }

uint32_t DG_GetTicksMs() { return platMs(); }

int DG_GetKey(int* pressed, unsigned char* key)
{
    pollInput();
    if (g_pad.quitRequested() && !g_quitting)
    {
        // tlačítko s kalkulačkou podržené: uložit nastavení a zpátky (I_Quit zavolá DG_Quit)
        g_quitting = true;
        I_Quit();
        platQuit();
    }
    return g_pad.popKey(*pressed, *key) ? 1 : 0;
}

void DG_SetWindowTitle(const char* title) { (void)title; }

} // extern "C"
