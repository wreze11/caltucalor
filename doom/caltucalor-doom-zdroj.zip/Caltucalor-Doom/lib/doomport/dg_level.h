// dg_level.h – výběr levelu a obtížnosti (Caltucalor, NOVÉ v7.9): stav hry a skok do levelu.
// Funkce jsou v C (dg_level.c), protože hlavičky Doomu jsou psané pro C. Licence: GPL v2.
#pragma once

#ifdef __cplusplus
extern "C" {
#endif

int DGL_InLevel(void);  // hraje se level (ne titulní obrazovka, demo ani mezihra)
int DGL_UserGame(void); // hráč už hrál (gamemap a gameskill jsou jeho)
int DGL_Map(void);      // gamemap (1–9)
int DGL_Skill(void);    // gameskill (0 = I'm too young to die … 4 = Nightmare!)
int DGL_Paused(void);
void DGL_SetPaused(int on);
// nová hra v E1M<map> s obtížností skill (jako New Game v menu / cheat IDCLEV); menu se zavře
void DGL_Warp(int map, int skill);

#ifdef __cplusplus
}
#endif
