// doompad.cpp – ovládání Doomu na displeji klávesnice (viz doompad.h). Licence: GPL v2 (jako Doom).
#include "doompad.h"

#include <math.h>
#include <stdio.h>
#include <string.h>

namespace dp {

namespace {

// klávesy Doomu (doomkeys.h)
const unsigned char K_UP = 0xad, K_DOWN = 0xaf, K_LEFT = 0xac, K_RIGHT = 0xae;
const unsigned char K_STRAFE_L = 0xa0, K_STRAFE_R = 0xa1, K_USE = 0xa2, K_FIRE = 0xa3;
const unsigned char K_ESC = 27, K_ENTER = 13, K_TAB = 9, K_SPEED = 0x80 + 0x36;

// držené klávesy: bit -> kód (pořadí = pořadí stisku; 'y' před USE – v otázce menu „ano“)
const unsigned char kKeys[] = {K_UP, K_DOWN, K_LEFT, K_RIGHT, K_SPEED, K_STRAFE_L, K_STRAFE_R,
                               'y', K_USE, K_FIRE, K_ENTER, K_TAB, K_ESC, DoomPad::kKeyNextWeapon};
enum KeyBit
{
    KB_UP, KB_DOWN, KB_LEFT, KB_RIGHT, KB_SPEED, KB_STRAFE_L, KB_STRAFE_R,
    KB_YES, KB_USE, KB_FIRE, KB_ENTER, KB_TAB, KB_ESC, KB_WEAPON, KB_COUNT
};

inline uint16_t rgb(int r, int g, int b) { return (uint16_t)(((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3)); }

const uint16_t C_BG = rgb(10, 11, 13);
const uint16_t C_BTN = rgb(30, 34, 40);
const uint16_t C_EDGE = rgb(58, 63, 71);
const uint16_t C_DOWN = rgb(92, 22, 16);
const uint16_t C_DOWN_EDGE = rgb(229, 57, 53);
const uint16_t C_STICK = rgb(19, 22, 26);
const uint16_t C_ARROW = rgb(107, 114, 128);
const uint16_t C_ARROW_ON = rgb(255, 90, 60);
const uint16_t C_ICON = rgb(154, 163, 173);

const uint32_t kExitHoldMs = 1200;

} // namespace

void DoomPad::begin(int w, int h, uint16_t* fb, const Wad* wad)
{
    w_ = w;
    h_ = h;
    fb_ = fb;
    wad_ = wad;
    state_ = keys_ = dirty_ = 0;
    exitSince_ = 0;
    quit_ = false;
    qHead_ = qTail_ = 0;
    layout();
}

void DoomPad::layout()
{
    auto R = [&](int x0, int y0, int x1, int y1) {
        Rect r;
        r.x = sx(x0);
        r.y = sy(y0);
        r.w = sx(x1) - r.x;
        r.h = sy(y1) - r.y;
        return r;
    };
    // horní řada
    rects_[Exit] = R(8, 6, 96, 48);
    rects_[Map] = R(104, 6, 204, 48);
    rects_[Weapon] = R(266, 6, 380, 48);
    rects_[Menu] = R(388, 6, 472, 48);
    // vpravo
    rects_[StrafeL] = R(248, 60, 354, 142);
    rects_[StrafeR] = R(366, 60, 472, 142);
    rects_[Use] = R(248, 152, 336, 312);
    rects_[Fire] = R(346, 152, 472, 312);
    // páčka vlevo
    cx_ = sx(122);
    cy_ = sy(186);
    rad_ = sx(112);
    stickArea_ = R(0, 54, 240, 320);
    const int a = sx(28), off = sx(70);
    rects_[Up] = Rect{cx_ - a, cy_ - off - a, 2 * a, 2 * a};
    rects_[Down] = Rect{cx_ - a, cy_ + off - a, 2 * a, 2 * a};
    rects_[Left] = Rect{cx_ - off - a, cy_ - a, 2 * a, 2 * a};
    rects_[Right] = Rect{cx_ + off - a, cy_ - a, 2 * a, 2 * a};
}

// ---------------------------------------------------------------- dotyky -> klávesy

void DoomPad::update(const Point* pts, int n, uint32_t now)
{
    uint32_t st = 0, keys = 0;
    bool stickUsed = false;
    for (int i = 0; i < n; i++)
    {
        const int x = pts[i].x, y = pts[i].y;
        if (stickArea_.contains(x, y) && !stickUsed)
        {
            // páčka: odchylka od středu v jednotkách návrhu (480 x 320)
            stickUsed = true;
            const float dx = (float)(x - cx_) * 480.0f / (float)w_;
            const float dy = (float)(y - cy_) * 320.0f / (float)h_;
            const float adx = fabsf(dx), ady = fabsf(dy);
            if (ady > 20.0f && ady > 0.4f * adx) st |= 1u << (dy < 0 ? Up : Down);
            if (adx > 26.0f && adx > 0.4f * ady) st |= 1u << (dx < 0 ? Left : Right);
            if (sqrtf(dx * dx + dy * dy) > 85.0f) keys |= 1u << KB_SPEED; // daleko od středu = běh
            continue;
        }
        for (int b = Exit; b <= Fire; b++)
            if (rects_[b].contains(x, y)) st |= 1u << b;
    }
    if (st & (1u << Up)) keys |= 1u << KB_UP;
    if (st & (1u << Down)) keys |= 1u << KB_DOWN;
    if (st & (1u << Left)) keys |= 1u << KB_LEFT;
    if (st & (1u << Right)) keys |= 1u << KB_RIGHT;
    if (st & (1u << StrafeL)) keys |= 1u << KB_STRAFE_L;
    if (st & (1u << StrafeR)) keys |= 1u << KB_STRAFE_R;
    if (st & (1u << Use)) keys |= (1u << KB_YES) | (1u << KB_USE);
    if (st & (1u << Fire)) keys |= (1u << KB_FIRE) | (1u << KB_ENTER);
    if (st & (1u << Map)) keys |= 1u << KB_TAB;
    if (st & (1u << Menu)) keys |= 1u << KB_ESC;
    if (st & (1u << Weapon)) keys |= 1u << KB_WEAPON;

    // návrat do kalkulačky: podržet
    if (st & (1u << Exit))
    {
        if (exitSince_ == 0) exitSince_ = now ? now : 1;
        if (now - exitSince_ >= kExitHoldMs) quit_ = true;
    }
    else
    {
        exitSince_ = 0;
    }

    // události: nejdřív puštěné, pak stisknuté (v pořadí kKeys)
    const uint32_t up = keys_ & ~keys, down = keys & ~keys_;
    for (int k = 0; k < KB_COUNT; k++)
        if (up & (1u << k)) pushKey(0, kKeys[k]);
    for (int k = 0; k < KB_COUNT; k++)
        if (down & (1u << k)) pushKey(1, kKeys[k]);
    keys_ = keys;

    // změny vzhledu
    const uint32_t changed = st ^ state_;
    state_ = st;
    for (int b = 0; b < kButtons; b++)
        if (changed & (1u << b))
        {
            drawButton((Button)b);
            markDirty((Button)b);
        }
}

void DoomPad::pushKey(int pressed, unsigned char key)
{
    const int next = (qTail_ + 1) % 64;
    if (next == qHead_) return; // plná fronta (nemělo by nastat)
    queue_[qTail_].pressed = (uint8_t)pressed;
    queue_[qTail_].key = key;
    qTail_ = next;
}

bool DoomPad::popKey(int& pressed, unsigned char& key)
{
    if (qHead_ == qTail_) return false;
    pressed = queue_[qHead_].pressed;
    key = queue_[qHead_].key;
    qHead_ = (qHead_ + 1) % 64;
    return true;
}

void DoomPad::markDirty(Button b) { dirty_ |= 1u << b; }

bool DoomPad::popDirty(Rect& r)
{
    for (int b = 0; b < kButtons; b++)
        if (dirty_ & (1u << b))
        {
            dirty_ &= ~(1u << b);
            r = rects_[b];
            return true;
        }
    return false;
}

// ---------------------------------------------------------------- kreslení

uint16_t DoomPad::pal(int idx) const
{
    int len = 0;
    const uint8_t* p = wad_ ? wad_->find("PLAYPAL", &len) : nullptr;
    if (p == nullptr || len < 768) return rgb(idx, idx, idx);
    return rgb(p[idx * 3], p[idx * 3 + 1], p[idx * 3 + 2]);
}

void DoomPad::fill(int x, int y, int w, int h, uint16_t c)
{
    if (x < 0)
    {
        w += x;
        x = 0;
    }
    if (y < 0)
    {
        h += y;
        y = 0;
    }
    if (x + w > w_) w = w_ - x;
    if (y + h > h_) h = h_ - y;
    if (w <= 0 || h <= 0) return;
    for (int yy = y; yy < y + h; yy++)
    {
        uint16_t* row = fb_ + (size_t)yy * w_ + x;
        for (int i = 0; i < w; i++) row[i] = c;
    }
}

void DoomPad::roundRect(const Rect& r, int rad, uint16_t c)
{
    for (int yy = 0; yy < r.h; yy++)
    {
        int inset = 0;
        const int dy = yy < rad ? rad - yy : (yy >= r.h - rad ? yy - (r.h - rad - 1) : 0);
        if (dy > 0)
        {
            const float d = (float)dy - 0.5f;
            inset = rad - (int)floorf(sqrtf((float)(rad * rad) - d * d) + 0.5f);
            if (inset < 0) inset = 0;
        }
        fill(r.x + inset, r.y + yy, r.w - 2 * inset, 1, c);
    }
}

void DoomPad::ring(int cx, int cy, int r0, int r1, uint16_t c)
{
    for (int yy = -r1; yy <= r1; yy++)
        for (int xx = -r1; xx <= r1; xx++)
        {
            const int d2 = xx * xx + yy * yy;
            if (d2 >= r0 * r0 && d2 <= r1 * r1)
            {
                const int px = cx + xx, py = cy + yy;
                if (px >= 0 && py >= 0 && px < w_ && py < h_) fb_[(size_t)py * w_ + px] = c;
            }
        }
}

void DoomPad::triangle(float x0, float y0, float x1, float y1, float x2, float y2, uint16_t c)
{
    const int minX = (int)floorf(fminf(x0, fminf(x1, x2))), maxX = (int)ceilf(fmaxf(x0, fmaxf(x1, x2)));
    const int minY = (int)floorf(fminf(y0, fminf(y1, y2))), maxY = (int)ceilf(fmaxf(y0, fmaxf(y1, y2)));
    const float area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
    if (fabsf(area) < 1e-3f) return;
    for (int y = minY; y <= maxY; y++)
        for (int x = minX; x <= maxX; x++)
        {
            const float px = (float)x + 0.5f, py = (float)y + 0.5f;
            const float w0 = (x1 - px) * (y2 - py) - (x2 - px) * (y1 - py);
            const float w1 = (x2 - px) * (y0 - py) - (x0 - px) * (y2 - py);
            const float w2 = (x0 - px) * (y1 - py) - (x1 - px) * (y0 - py);
            const bool in = area > 0 ? (w0 >= 0 && w1 >= 0 && w2 >= 0) : (w0 <= 0 && w1 <= 0 && w2 <= 0);
            if (in && x >= 0 && y >= 0 && x < w_ && y < h_) fb_[(size_t)y * w_ + x] = c;
        }
}

// písmo Doomu: lumpy STCFN033 … STCFN095 (znaky '!' … '_')
namespace {
const uint8_t* glyph(const Wad* wad, char ch)
{
    if (wad == nullptr) return nullptr;
    if (ch >= 'a' && ch <= 'z') ch = (char)(ch - 'a' + 'A');
    if (ch < 33 || ch > 95) return nullptr;
    char name[9];
    snprintf(name, sizeof name, "STCFN%03d", ch);
    return wad->find(name);
}
} // namespace

int DoomPad::textWidth(const char* s, float scale) const
{
    float w = 0;
    for (; *s; s++)
    {
        const uint8_t* g = glyph(wad_, *s);
        w += g ? (float)Wad::le16(g) : 4.0f;
    }
    return (int)(w * scale + 0.5f);
}

void DoomPad::text(int x, int y, const char* s, float scale)
{
    float cx = (float)x;
    for (; *s; s++)
    {
        const uint8_t* g = glyph(wad_, *s);
        if (g == nullptr)
        {
            cx += 4.0f * scale;
            continue;
        }
        const int gw = Wad::le16(g);
        for (int col = 0; col < gw; col++)
        {
            const uint8_t* post = g + Wad::le32(g + 8 + col * 4);
            while (*post != 0xFF)
            {
                const int top = post[0], len = post[1];
                const uint8_t* px = post + 3;
                for (int i = 0; i < len; i++)
                {
                    const int x0 = (int)floorf(cx + (float)col * scale), x1 = (int)floorf(cx + (float)(col + 1) * scale);
                    const int y0 = y + (int)floorf((float)(top + i) * scale), y1 = y + (int)floorf((float)(top + i + 1) * scale);
                    fill(x0, y0, x1 - x0, y1 - y0, pal(px[i]));
                }
                post += len + 4;
            }
        }
        cx += (float)gw * scale;
    }
}

void DoomPad::textCentered(const Rect& r, const char* s, float scale)
{
    const int tw = textWidth(s, scale);
    const int th = (int)(7.0f * scale + 0.5f); // písmena jsou 7 px vysoká
    text(r.x + (r.w - tw) / 2, r.y + (r.h - th) / 2, s, scale);
}

void DoomPad::drawButton(Button b)
{
    const bool on = pressed(b);
    const float big = 3.0f * (float)w_ / 480.0f, small = 2.0f * (float)w_ / 480.0f;
    if (b >= Up)
    {
        // šipka páčky
        const Rect& r = rects_[b];
        fill(r.x, r.y, r.w, r.h, C_STICK);
        const float cx = r.x + r.w * 0.5f, cy = r.y + r.h * 0.5f, s = r.w * 0.36f;
        const uint16_t c = on ? C_ARROW_ON : C_ARROW;
        switch (b)
        {
        case Up: triangle(cx, cy - s, cx + s, cy + s * 0.6f, cx - s, cy + s * 0.6f, c); break;
        case Down: triangle(cx, cy + s, cx - s, cy - s * 0.6f, cx + s, cy - s * 0.6f, c); break;
        case Left: triangle(cx - s, cy, cx + s * 0.6f, cy - s, cx + s * 0.6f, cy + s, c); break;
        default: triangle(cx + s, cy, cx - s * 0.6f, cy + s, cx - s * 0.6f, cy - s, c); break;
        }
        return;
    }
    const Rect& r = rects_[b];
    const int rad = sx(10), edge = sx(2) < 1 ? 1 : sx(2);
    fill(r.x, r.y, r.w, r.h, C_BG);
    roundRect(r, rad, on ? C_DOWN_EDGE : C_EDGE);
    Rect in{r.x + edge, r.y + edge, r.w - 2 * edge, r.h - 2 * edge};
    roundRect(in, rad - edge, on ? C_DOWN : C_BTN);
    switch (b)
    {
    case Exit:
    {
        // malá kalkulačka (podržením zpět)
        const int iw = sx(22), ih = sy(28);
        const int x0 = r.x + (r.w - iw) / 2, y0 = r.y + (r.h - ih) / 2;
        Rect body{x0, y0, iw, ih};
        roundRect(body, sx(3), C_ICON);
        fill(x0 + sx(3), y0 + sy(3), iw - 2 * sx(3), sy(7), on ? C_DOWN : C_BTN); // displej
        for (int ky = 0; ky < 3; ky++)
            for (int kx = 0; kx < 3; kx++)
                fill(x0 + sx(4) + kx * sx(5), y0 + sy(13) + ky * sy(5), sx(3), sy(3), on ? C_DOWN : C_BTN);
        break;
    }
    case Map: textCentered(r, "MAP", small); break;
    case Weapon: textCentered(r, "WEAPON", small); break;
    case Menu: textCentered(r, "MENU", small); break;
    case StrafeL: textCentered(r, "<<", big); break;
    case StrafeR: textCentered(r, ">>", big); break;
    case Use: textCentered(r, "USE", big); break;
    case Fire: textCentered(r, "FIRE", big); break;
    default: break;
    }
}

void DoomPad::message(const char* title, const char* msg)
{
    fill(0, 0, w_, h_, C_BG);
    const float big = 3.0f * (float)w_ / 480.0f, small = 2.0f * (float)w_ / 480.0f;
    Rect t{0, sy(40), w_, sy(40)};
    textCentered(t, title, big);
    // text po slovech do řádků
    char line[96];
    int y = sy(110);
    const int maxW = w_ - sx(40);
    const char* p = msg;
    while (*p && y < h_ - sy(24))
    {
        int len = 0, lastSpace = -1;
        while (p[len] && p[len] != '\n' && len < (int)sizeof(line) - 1)
        {
            memcpy(line, p, (size_t)len + 1);
            line[len + 1] = 0;
            if (textWidth(line, small) > maxW) break;
            if (p[len] == ' ') lastSpace = len;
            len++;
        }
        int take = len;
        if (p[len] && p[len] != '\n' && lastSpace > 0) take = lastSpace;
        if (take <= 0) take = 1;
        memcpy(line, p, (size_t)take);
        line[take] = 0;
        Rect r{0, y, w_, sy(22)};
        textCentered(r, line, small);
        y += sy(26);
        p += take;
        while (*p == ' ' || *p == '\n') p++;
    }
    dirty_ = 0;
}

void DoomPad::drawAll()
{
    fill(0, 0, w_, h_, C_BG);
    // páčka: tmavý kruh s okrajem
    for (int yy = -rad_; yy <= rad_; yy++)
    {
        const int half = (int)floorf(sqrtf((float)(rad_ * rad_ - yy * yy)));
        fill(cx_ - half, cy_ + yy, 2 * half + 1, 1, C_STICK);
    }
    const int edge = sx(3) < 2 ? 2 : sx(3);
    ring(cx_, cy_, rad_ - edge, rad_, C_EDGE);
    ring(cx_, cy_, sx(16), sx(18), C_EDGE); // střed
    for (int b = 0; b < kButtons; b++) drawButton((Button)b);
    dirty_ = 0;
}

} // namespace dp
