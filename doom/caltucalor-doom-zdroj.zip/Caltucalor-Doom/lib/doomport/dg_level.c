// dg_level.c – výběr levelu a obtížnosti (Caltucalor, NOVÉ v7.9), viz dg_level.h. Licence: GPL v2.
#include "dg_level.h"

#include "d_main.h"
#include "doomstat.h"
#include "g_game.h"

extern boolean advancedemo; // d_main.c

int DGL_InLevel(void) { return gamestate == GS_LEVEL && !demoplayback && usergame; }
int DGL_UserGame(void) { return usergame && !demoplayback; }
int DGL_Map(void) { return gamemap; }
int DGL_Skill(void) { return (int)gameskill; }
int DGL_Paused(void) { return paused ? 1 : 0; }
void DGL_SetPaused(int on) { paused = on ? true : false; }

void DGL_Warp(int map, int skill)
{
    if (map < 1) map = 1;
    if (map > 9) map = 9;
    if (skill < (int)sk_baby) skill = (int)sk_baby;
    if (skill > (int)sk_nightmare) skill = (int)sk_nightmare;
    menuactive = false;
    advancedemo = false; // (aby titulní obrazovka nespustila demo místo nové hry)
    G_DeferedInitNew((skill_t)skill, 1, map);
}
